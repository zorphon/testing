from sense_hat import SenseHat

sense = SenseHat()

r = 0
g = 255
b = 0

sense.clear((r, g, b))
