from sense_hat import SenseHat

sense = SenseHat()
sense.clear()



temp = sense.get_temperature()
print(((temp/5)*9)+31)
