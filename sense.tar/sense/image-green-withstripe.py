from sense_hat import SenseHat

sense = SenseHat()

# Define some colours
g = (0, 255, 0) # Green
b = (0, 0, 0) # Black

# Set up where each colour will display
creeper_pixels = [
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g,
    g, g, g, b, b, g, g, g
]

# Display these colours on the LED matrix
sense.set_pixels(creeper_pixels)
