from sense_hat import SenseHat

sense = SenseHat()

r = 0
g = 0
b = 255

sense.clear((r, g, b))
