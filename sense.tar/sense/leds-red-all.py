from sense_hat import SenseHat

sense = SenseHat()

r = 255
g = 0
b = 0

sense.clear((r, g, b))
