from sense_hat import SenseHat
sense = SenseHat ()
sense.clear ()
sense.show_message("HI DAD", text_colour=(255,0,0), scroll_speed=0.2)
sense.clear ()
