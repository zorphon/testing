from sense_hat import SenseHat

sense = SenseHat()
sense.clear()

temp = sense.get_temperature()
tempf = (((temp/5)*9)+31)
print(tempf)

humidity = sense.get_humidity()
print(humidity)

pressure = sense.get_pressure()
print(pressure)

message = '%d' %(tempf)
sense.show_message(message,scroll_speed=0.5,text_colour=(0,0,255))
