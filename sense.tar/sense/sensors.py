from sense_hat import SenseHat

sense = SenseHat()
sense.clear()

temp = sense.get_temperature()
tempf = (((temp/5)*9)+31)
print(tempf)

humidity = sense.get_humidity()
print(humidity)

pressure = sense.get_pressure()
print(pressure)
